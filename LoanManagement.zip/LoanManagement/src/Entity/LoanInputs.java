package Entity;

public class LoanInputs {

	private String name;
	private String email;
	private String contact;
	private String city;
	private String typeOfEmployment;
	private String salary;
	
	
	
	public LoanInputs(String name, String email, String contact, String city, String typeOfEmployment, String salary) {
		super();
		this.name = name;
		this.email = email;
		this.contact = contact;
		this.city = city;
		this.typeOfEmployment = typeOfEmployment;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTypeOfEmployment() {
		return typeOfEmployment;
	}
	public void setTypeOfEmployment(String typeOfEmployment) {
		this.typeOfEmployment = typeOfEmployment;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	
	
	
	
	
	
}