package pack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity.LoanInputs;

import Entity.LoanInputs;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/Serv")
public class Serv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv() {
        super();
        // TODO Auto-generated constructor stub
    }

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String contact = request.getParameter("contact");
		String city = request.getParameter("city");
		String typeOfEmployment = request.getParameter("typeOfEmployment");
		String salary = request.getParameter("salary");
		
        LoanInputs loaninput = new LoanInputs(name, email, contact,city,typeOfEmployment,salary);
  		
		// 1. share this data with jsp page
		// 2. scope of access
		
		// request scope
		request.setAttribute("loaninput", loaninput);
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("EligibilitySuccessDetails.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
